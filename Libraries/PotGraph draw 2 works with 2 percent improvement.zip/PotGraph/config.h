// Screen
#define LCD_WIDTH 128
#define LCD_HEIGHT 64
#define LCD_ADDR 0x3C
#define LCD_RST_PIN -1

// Dial Graph
#define INVERT_DIAL_LABEL false
